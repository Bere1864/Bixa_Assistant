package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import android.widget.ImageView;
import android.view.View;
import android.net.Uri;
import android.content.IntentSender;



public class MainActivity extends AppCompatActivity {


    ImageView imag;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imag = (ImageView) findViewById(R.id.imageView);
    }
    
    
    public void onclick(View view){
        cargarImagen();
    }

    public void cargarImagen(){
        Intent intent = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/");

        //onActivityResult(10,10,intent.createChooser(intent,"Seleccione la Aplicacion"));
        //startActivityForResult(intent.createChooser(intent,"Seleccione la Aplicacion"),requestCode);
        startActivityForResult(intent.createChooser(intent,"Seleccione la Aplicacion"),10);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,Intent data){
        super.onActivityResult(requestCode, resultCode,data);
        if(resultCode == RESULT_OK){
            Uri path = data.getData();
            imag.setImageURI(path);
        }
    }
}