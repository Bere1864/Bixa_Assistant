
package chis;
import chis.Chis;
import java.util.*;
public class Principal {
    public static void main(String []args){
        Scanner sc = new Scanner(System.in);
        Keywords palabra = new Keywords();
        /*
        System.out.println("Chiste: " + Chis.getChiste());
        System.out.println(Saludos.getSaludo() + " " + "fernanda");
        System.out.println(Saludos.getDespedida()+ " " + "fernanda");
        
        System.out.println("Sabías que " + Datos.getDatosInteresantes());
        
        sc.nextLine();*/
        palabra.hasheado();
        System.out.println("Ingreses palabra: ");
        palabra.imprimirColeccion(palabra.busqueda(sc.nextLine()));
        
        
    }
   
    
}
