package com.example.alarma_;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Agregar_Alarma extends AppCompatActivity {

    EditText HourEditText;
    EditText MinuteEditText;

    Button SetAlarmButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        HourEditText = (EditText) findViewById(R.id.Horas);
        MinuteEditText = (EditText) findViewById(R.id.Minutos);

        SetAlarmButton = (Button) findViewById(R.id.set_alarm);
        SetAlarmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hora = Integer.parseInt(HourEditText.getText().toString());
                int minute = Integer.parseInt(MinuteEditText.getText().toString());
                String bixa_Alarm = "Alarma asignada por BIXA";

                Intent intent = new Intent(AlarmClock.ACTION_SET_ALARM);
                intent.putExtra(AlarmClock.EXTRA_SKIP_UI,true);
                intent.putExtra(AlarmClock.EXTRA_HOUR, hora);
                intent.putExtra(AlarmClock.EXTRA_MINUTES,minute);
                intent.putExtra(AlarmClock.EXTRA_MESSAGE,bixa_Alarm);

                if(hora <= 23 && minute <= 59) {
                    startActivity(intent);

                }
            }
        });
    }
    public void Atras(View view){
        Intent back = new Intent(this, MainActivity.class);
        startActivity(back );
    }
}