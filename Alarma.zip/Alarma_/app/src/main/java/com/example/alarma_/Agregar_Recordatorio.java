package com.example.alarma_;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.Data;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.UUID;

public class Agregar_Recordatorio extends AppCompatActivity {

    Button SelFecha, SelHora;
    TextView Evento1;
    Button reminder;

    Calendar actual = Calendar.getInstance();
    Calendar calendario = Calendar.getInstance();
    private int minutos,hora,dia,mes,anio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        SelFecha = findViewById(R.id.SFecha);
        SelHora = findViewById(R.id.SHora);
        Evento1 = findViewById(R.id.Evento);
        reminder = findViewById(R.id.set_reminder);

        SelFecha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                anio = actual.get(Calendar.YEAR);
                mes = actual.get(Calendar.MONTH);
                dia = actual.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(v.getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int y, int m, int d) {
                        calendario.set(Calendar.DAY_OF_MONTH, d);
                        calendario.set(Calendar.MONTH, m);
                        calendario.set(Calendar.YEAR, y);

                        SimpleDateFormat format = new SimpleDateFormat( "dd/MM/yyyy");
                        String strDate = format.format(calendario.getTime());
                    }
                },anio,mes,dia);
                datePickerDialog.show();
            }
        });
        SelHora.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hora=actual.get(Calendar.HOUR_OF_DAY);
                minutos=actual.get(Calendar.MINUTE);

                TimePickerDialog timePickerDialog = new TimePickerDialog(v.getContext(), new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int h, int min) {
                        calendario.set(Calendar.HOUR_OF_DAY,h);
                        calendario.set(Calendar.MINUTE,min);

                        String strHour = String.format("%02d:%02d",h,min);
                    }
                },hora,minutos, true);
                timePickerDialog.show();
            }
        });

        String recordatorio = Evento1.getText().toString();

        reminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tag = generateKey();
                Long AlertTime = calendario.getTimeInMillis() - System.currentTimeMillis();
                int random = (int)(Math.random()*50+1);

                Data data = guardarData("Recordatorio con Bixa","Tienes un recordatorio para hoy", random);
                WorkManagerNotificaciones.GuardaN(AlertTime,data,tag);

                Toast.makeText(Agregar_Recordatorio.this, "Recordatorio establecido", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String generateKey(){
        return UUID.randomUUID().toString();
    }
    private Data guardarData(String titulo, String detalle, int id_noti){
        return new Data.Builder()
                .putString("titulo", titulo)
                .putString("detalle", detalle)
                .putInt("id_noti", id_noti).build();
    }
    public void Atras(View view) {
        Intent back = new Intent(this, MainActivity.class);
        startActivity(back);
    }
}